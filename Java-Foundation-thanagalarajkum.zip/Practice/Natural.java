import java.util.*;
class Natural{
    public static void main(String args[]){
        int i=1,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the n value");
        n=sc.nextInt();
        while(i<=n){
            System.out.println(i+ " ");
            i++;
        }
        
    }
}