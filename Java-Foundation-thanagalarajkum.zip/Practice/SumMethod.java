/*import java.util.*;
class SumMethod
  {
    //no return type no Arguments
    public static void mult() 
    {
      Scanner sc=new Scanner(System.in);
        System.out.println("enter the a value");
        int a=sc.nextInt();
      System.out.println("enter the a value");
        int b=sc.nextInt();
      
      int mult=a*b;
      System.out.println("the mul of two numbers is :"+mult);
    }
    public static void main(String args[])
    {
      mult(); 
      
    }
  }*/

/*import java.util.*;
class SumMethod
  {
    //no return type with  Arguments
    public static void mult(int a,int b) 
    {
          
      int mult=a*b;
      System.out.println("the mult of two numbers is :"+mult);
    }
    public static void main(String args[])
    {
      mult(10, 20);       
    }
  }*/
/*import java.util.*;
class SumMethod
  {

    public static void square() 
    {
      Scanner sc=new Scanner(System.in);
        System.out.println("enter the a value");
        int a=sc.nextInt();
      System.out.println("enter the a value");
        int a=sc.nextInt();
      
      int square=a*a;
      System.out.println("the square of two numbers is :"+square);
    }
    public static void main(String args[])
    {
      square(); 
      
    }
  }
import java.util.*;
clas SumMethod
  {
    //no return type with arguments
    public static void Area(int a)
    {
      int Area=a*a;
      System.out.println("the area of the square is "+Area);
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the x value ");
      int x=sc.nextInt();
      System.out.println("the exacution starts from");
      Area(x);
    }
  }*/
class SumMethod {
  public static void sub(){
    int a=100; int b=71;
    int c=a-b;
    System.out.println("the sub of 2 numbers:"+c);
  }
  public static void main(String args[]){
    sub();
  }
}