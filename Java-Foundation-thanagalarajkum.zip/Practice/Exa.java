//import java.util.*;
/*class Exa {
  public static void main(String args[]) {   
      String s ="hello@123";  
    int acount=0,scount=0,dcount=0;
    for (int i=0;i<s.length();i++) {
      if((s.charAt(i)>='a'&&s.charAt(i)<='z')||s.charAt(i)>='A'&&s.charAt(i)<='Z'){
        acount++;
      }        
        else if(s.charAt(i)>='0'&&s.charAt(i)<='9'){
          dcount++;
          }      
      else{
        scount++;
      }      
    }
    System.out.println("alphabets count in the give string is :"+acount);
      System.out.println("Digits count in the give string is :"+dcount);
      System.out.println("special characters count in the give string is :"+scount);
  }  
}
//welocome to bitlabs
class Exa {
  public static void main(String args[]) {   
      String s ="welocome to bitlabs";  
        String arr[] =s.split(" ");//[welcome,to,bitlabs]
     String sword="";               //   0     1    2
     int leng=arr[0].length();/// length of arr is 3
       for(int i=0;i<arr.length;i++){         
      if(arr[i].length()<=leng){/// 6<2  
        sword=arr[i];  
    }                
  } 
    System.out.println("the lowest word"+sword);
}
}*/






