//for each loop
class ForEach
  {
    public static void main(String args[])
    {
      float arr[]={10.2f,14.5f,24.5f,25.5f};
      System.out.println("array elements are");
      for(float x:arr)
        {
          System.out.print(x);
        }
    }
  }