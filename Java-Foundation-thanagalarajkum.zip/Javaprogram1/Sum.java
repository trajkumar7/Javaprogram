/*class String
{
  public static void main(String args[]){
   /* String s="hello";
    String s1= new String("raj");
    System.out.println(s);
    System.out.println(s1);/

    
  
  }
}*/
  

/*}
class String
  {
    public static void main(String[]args)
    {
      String nc="raj";
      String sc=new String("kumar");
      System.out.println(nc);
      System.out.println(sc);
      String s="raj";
      if(s==nc)
      {
      System.out.println(nc);
      }else
      {
        System.out.println(s);
      }
    }
  }*/
class Sum
  {
    public static void main(String args[])
    {
      String s="hello";
     System.out.println("length of the string is :"+ s.length());
      for(int i=0;i<s.length();i++)
        {
  
         System.out.println(s.charAt(i));
        }
    }
  }