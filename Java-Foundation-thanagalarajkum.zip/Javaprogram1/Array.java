//// by using the scanner class and print the values of "i"
import java.util.*;
class Array{
  public static void main(String ars[]){
    int a[]=new int[8];
   Scanner sc=new Scanner(System.in);
    System.out.println("enter the elementss:");
    a[0]=sc.nextInt();
    a[1]=sc.nextInt();
    a[2]=sc.nextInt();
    a[3]=sc.nextInt();
    a[4]=sc.nextInt();
    a[5]=sc.nextInt();
    a[6]=sc.nextInt();
    a[7]=sc.nextInt();
    System.out.println("the array elements are ");
      for(int i=0;i<10;i++)
        {
          System.out.println(a[i]);
        }      

    //String arr[]={"raj kumar","ramesh","anudeep","durga"};
      //System.out.println(arr elements are[]);
    //for(int i=0;i<n;i++){
     //  System.out.println(arr[i]);
  
  }
}


// by using float values 
/*import java.util.*;
class Array{
  public static void main(String ars[]){
    float a[]=new float[8];
   Scanner sc=new Scanner(System.in);
    System.out.println("enter the elementss:");
    a[0]=sc.nextFloat();
    a[1]=sc.nextFloat();
    a[2]=sc.nextFloat();
    a[3]=sc.nextFloat();
    a[4]=sc.nextFloat();
    a[5]=sc.nextFloat();
    a[6]=sc.nextFloat();
    a[7]=sc.nextFloat();
    System.out.println("the array elements are ");
      for(int i=0;i<6;i++)
        {
          System.out.println(a[i]);
        }      
  }
} */
/*// by using Char
import java.util.*;
class Array
  {
    public static void main(String args[])
    {
      char ch[]=new char[5];
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the values ");
      for(int i=0;i<5;i++)
        {
          ch[i]=sc.next().charAt(0);
        }
      System.out.println("the array values are");
      for(int i=0;i<5;i++)
        {
          System.out.print(ch[i]+" ");
        }
    }
  
  // by using String 
import java.util.*;
class Array
  {
    public static void main(String args[])
    {
      String a[]=new String[5];
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the values ");
      for(int i=0;i<5;i++)
        {
          a[i]=sc.next();
        }
      System.out.println("the array values are");
      for(int i=0;i<5;i++)
        {
          System.out.print(ch[i]+" ");
        }
    }
  }*/



