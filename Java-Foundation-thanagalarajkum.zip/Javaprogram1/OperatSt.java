class Operat1
  {
    public static void main(String args[])
    {
      String s="java";
      //String s1="hello";
      //String s2="welcome";
      String s3="program";
      // System.out.println(s1.compareTo(s2)); 
      //System.out.println(s1.compareTo(s3));
      //System.out.println(s1.compareTo(s2));
      System.out.println(s.compareTo(s3));
    }
}