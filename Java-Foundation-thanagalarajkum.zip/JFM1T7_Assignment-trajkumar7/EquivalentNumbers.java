/* JFM1T7_Assignment3:

   Accept an integer number as input from the console and when the program is executed print the binary, octal and hexadecimal equivalent of the given number.
   Prompt the user for the  values to be input from the terminal
   Hint: Refer Java Documentation and look for the appropriate Wrapper class method

   Sample Input: 20
   
   Expected Output: Binary equivalent: 10100 Octal equivalent: 24 Hexadecimal equivalent: 14
   
*/

public class EquivalentNumbers {

//Main method
public static void main(String args[]) {
    int num = 20;
 
    System.out.println("Binary equivalent :" +Integer.toBinaryString(num)+" "+"Octal equivalent: " +Integer.toOctalString(num)+" "+"Hexadecimal equivalent: " + Integer.toHexString(num));                  
 
    
  }
//initialize Convert class constructor

//create Scanner object

//take input from user

//convert numbers into hexa,octal and binary

//print result
     
}

//create Convert class in that declare variables

//add getters and setters method
