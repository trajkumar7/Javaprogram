/*  JFM1T12_Assignment2:

    Write a program to sort a given arraylist of integers in ascending order.   
    Prompt the user input from the terminal.
    
    Sample Input:
    Enter how many numbers you want: 
    5
    Enter Number 0
    467
    Enter Number 1
    342
    Enter Number 2
    167
    Enter Number 3
    511
    Enter Number 4
    204
    
    Expected Output:
    ArrayList After Sorting:
    167
    204
    342
    467
    511

*/     

import java.util.*;  

public class SortArrayList  {  
//main method
public static void main(String []args){
//declare variables
Scanner sc=new Scanner(System.in);
//create Scanner object
System.out.println("Enter how many numbers you want: ");
  int size=sc.nextInt();
//take input from user
  ArrayList<Integer> al=new ArrayList<>();
for (int i=0;i<size;i++){
  System.out.println("Enter Number: "+(0+i));
  al.add(sc.nextInt());
 } System.out.println("ArrayList Before Sorting:"  +al);
  
//create an object of ArrayList class
  System.out.println("ArrayList After Sorting:");
  Collections.sort(al);
 
  for(Integer value : al){
System.out.println(value); 
  }
 class ArrayList {
    
  }
 
//sort ArrayList in ascending oeder

//print Array list
}
}