package packag;
public class Myclass {
  public void display()
  {
    System.out.println("welcome to packages");
  }

}