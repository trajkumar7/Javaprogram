/*import java.util.*;
class Power{
  public static void main(String args[]){
  int power,base,res=1;
  Scanner sc=new Scanner(System.in);
    System.out.println("enter the power of numbers:");
    power=sc.nextInt();
    System.out.println("enter the base value:");
    base=sc.nextInt();
    for(int i=1;i<=power;i++)
      {
        res=res*base;
      }
    System.out.println("the power of value is:"+res);
  }
}*/
///print hello for n times
/*class Power{
  public static void main(String args[]){
  int i;
    for(i=1;i<=10;i++)
    {
      System.out.println("hello world");
      
    }
  }
}*/