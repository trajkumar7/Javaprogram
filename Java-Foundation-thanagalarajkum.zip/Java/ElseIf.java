 class ElseIf
{
  public static void main(String args[])
{
String name="rajkumar";
if(name=="raj")
{
System.out.println("raj is my name");
}
else if(name=="kumar")
{
System.out.println("kumar is my name");
}
else if(name=="rajkumar")
{
System.out.println("rajkumar is my name");
}
else
{
System.out.println("all these are not my names");
}
}
}
/*[10:45 AM] Sowjanya Uppu
    class Sample3
{​​
public static void main(String args[])
{​​
String name="sowjanya";
if(name=="lalitha")
{​​
System.out.println("lalitha is my name");
}​​
else if(name=="radha")
{​​
System.out.println("radha is my name");
}​​
else if(name=="latha")
{​​
System.out.println("latha is my name");
}​​
else
{​​
System.out.println("all these are not my names");
}​​
}​​
}​​
​[10:51 AM] Sowjanya Uppu
    import java.util.*;
class Sample3
{​​
public static void main(String args[])
{​​
int a,b,c;
Scanner sc=new Scanner(System.in);
System.out.println("enter a,b,c values");
a=sc.nextInt();
b=sc.nextInt();
c=sc.nextInt();
if(a>b && a>c)
{​​
System.out.println("a is bigger");
}​​
else if(b>c && b>a)
{​​
System.out.println("b is bigger");
}​​
else
{​​
System.out.println("c is bigger");
}​​
}​​
}​​
*/