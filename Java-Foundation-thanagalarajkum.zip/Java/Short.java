//Short operator
class Short {
  public static void main(String args[]){
    int a=120,b=20;
System.out.println(a);
a+=7;
System.out.println(a); 
a-=3;
System.out.println(a);
a*=6;
System.out.println(a);
a/=2;
System.out.println(a);
a%=8;
System.out.println(a);

  }
}
