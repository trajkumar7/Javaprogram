//the percentage of subjects
import java.util.*;
class Total{
  public static void main(String args[]){
    int tel,engl,math,scie,socl;
  	Scanner read = new Scanner(System.in); // Input stream is used
    System.out.println("enter tel marks");
    tel=read.nextInt();
    System.out.println("enter eng marks");
    engl=read.nextInt();
    System.out.println("enter math marks");
    math=read.nextInt();
    System.out.println("enter scie marks");
    scie=read.nextInt();
    System.out.println("enter socl marks");
    socl=read.nextInt();
    double total=tel+engl+math+scie+socl;
    double percentage= (total/500)*100;
    System.out.println("the percentage of total subjects is "+percentage);
    
    

     
  }
}