class SumOfSquare{
  public static void main(String args[]){
    int a=10, b=20;
    int sum=a+b;
    int y=sum*sum;
    System.out.println("sum of square route of two numbers:"+y);
  }
}