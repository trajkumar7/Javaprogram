//1 to n odd numbers and print how many numbes are their
/*import java.util.*;
class Whileloop2{
  public static void main(String args[]){
    int i=1,n,sum=0;
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the n value:");
    n=sc.nextInt();
    while(i<=n)
      {
        if(i%2!=0)
        {
          System.out.println(i);
          sum=sum+1;
        }   
      i++;
      }      
    System.out.println("sum of odd numbers" +sum);
  }
  
}*/
//