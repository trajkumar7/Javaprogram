//sample proghram on display hello world,welcome to java
class Sample{
  public static void main (String args[]){
    //System.out.println("hello world, welcome to java program");
    //System.out.println("my name is rajkumar, s/o Sundar Rao");
    //System.out.println("my name is lakshmi m/o of rajkumar");
    //int x=100;
    //char z='a';
    //byte y=6;
    //float a=97.65f;
    //double b=1.123456877942587;
    //long number=96529105;
    //short c=-27400;
    //boolean t= true;
   // String name="Rajkumar";
    int a=30,b=40,c=5;
    int x=a+b+c;
    int z=x/3;
      
    System.out.println("avg of numbers:"+(z));
  
      
    
    //System.out.println("the value of x is"+x+"printed");
    //System.out.println("the char of z is"+z);
    //System.out.println("the byte value of y is"+y);
    //System.out.println("the float number of ais"+a);
    //System.out.println("the double of b is"+b);
    //System.out.println(number+ "this the  longnumber");
    //System.out.println("the short number of cis"+c);  
    //System.out.println("print t" +t);
    //System.out.println("my name is"+name);
  }
}
  