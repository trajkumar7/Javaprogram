      class Swaping{
  public static void main(String args[]){
    int a=10, b=5;
    System.out.println("before swap the numbers a is"+a+"b is "+b);
    
     a=a+b;//15
     b=a-b;//10
     a=a-b;//5
    System.out.println("after swap of two numbers a is" +a+"b is" +b);
  }
  
}
