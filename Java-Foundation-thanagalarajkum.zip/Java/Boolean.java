import java.util.*;
class Boolean{
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the boolean value;");
    boolean a=sc.nextBoolean();
    boolean d=!a;
    System.out.println("the boolean valus !a" +d);
  }
}