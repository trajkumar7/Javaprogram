////1 to n number odd and how many number in that
/*import java.util.*;
class WhileLoop{
  public static void main(String args[]){
    int i=1,n,sum=0;
    Scanner sc=new Scanner(System.in);
    System.out.println("enter n value");
      n=sc.nextInt();
    while (i<=n)
      {
       if(i%2!=0)
        {
           System.out.println(i);
           sum=sum+1;
        }
         i++;
      }    
    System.out.println("the sum of number:"+sum);
  }
}*/
/// even numbers and print sum of total numbers
import java.util.*;
class  WhileLoop
  {
    public static void main(String args[])
    {
      int i=1,n,sum=0;
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the value of n");
      n=sc.nextInt();
      while(i<=n)
        {
          if(i%2==0)
          {
          System.out.println(i);
            sum=sum+i;
           
           }
      i++;    
      }
       System.out.println(" sum of odd num"+sum);
   }
  }
////table write program
/*
import java.util.*;
class WhileLoop{
  public static void main(String args[]){
    int i=1,x,n;
    Scanner sc=new Scanner(System.in);
    System.out.println("enter which table you want:");
    x=sc.nextInt();
    System.out.println("enter the n value:");
    n=sc.nextInt();
    while(i<=n)
    {
      int res=(x*i);
      System.out.println(x+"*"+i+"="+(res));
      i++;
    }
    
  }
}*/
/*import java.util.*;
class WhileLoop
  {
    public static void main(String args[])
    {
      int i=1,x,n;
      Scanner sc= new Scanner(System.in);
      System.out.println("the table is");
      x=sc.nextInt();
      System.out.println("the n value is ");
     n=sc.nextInt();
      while(i<=n)
        {
          int result=(x*i);
          System.out.println(x+"*"+i+"="+result);
          i++;
        }
    }
  }*/