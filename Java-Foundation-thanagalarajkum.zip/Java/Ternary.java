class Ternary{
  public static void main(String args[]){
  int a=10, b=20,c=25;
    int d=(a>b)?a:b;
    /*int max=(a>b)? 
      (a>c?a:c);
      (b>c?b:c); */
    System.out.println(d);
  }
}