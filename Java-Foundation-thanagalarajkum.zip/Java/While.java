import java.util.*;
class While{
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the Char:");
    char character=sc.next().charAt(0);
    do {
      System.out.println(ch+ " ");
      ch++;
    }
      while(cha<='Z')
  }
}  