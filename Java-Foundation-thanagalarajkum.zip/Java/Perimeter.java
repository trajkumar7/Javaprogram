class Perimeter{
  public static void main(String args[]){
    double a=4.5;
    double p= 4*(a);
    System.out.println("perimeter of square is"+p);
  }
}