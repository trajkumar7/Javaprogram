/*class TestClass
{
 String name="rajkumar";
  int id=20;
    class Inner
    {
        void display()
        {
            System.out.println("the student name is"+name+" "+"and"+"id "+id);
        }
    }
    public static void main(String args[])
    {
        TestClass obj=new TestClass();
        TestClass.Inner in=obj.new Inner();
        in.display();
    }
}*/
class TestClass
{
    String name="Raj";
    int age=23;
    String add="Hunmanjunction";
    String name1="Anu";
   int age1 =23;
  String add1="vizag";
    class student
    {
     void display()
      {
         System.out.println("the student details are "+name+" Age "+age+" Address "+add);
        System.out.println("the student details are "+name1+" Age "+age1+" Address "+add1);
        }
    }
    public static void main(String args[])
    {
        TestClass obj=new TestClass();
        TestClass.student in=obj.new student();
        in.display();
    }
}