import java.util.Scanner;
class Switch
  {
    public static void main(String args[])
    {
     int option,amount,pin,a,b;
      Scanner sc=new Scanner(System.in);
      System.out.println("******ATM********");
      System.out.println("1.withdraw");
      System.out.println("2.mini statement");
      System.out.println("3.balance");
      System.out.println("4.pin change");
      System.out.println("5.others");
      System.out.println("entr option:");
      option=sc.nextInt();
      System.out.println("incert the atm card and enter pin ");
      pin=sc.nextInt();
      System.out.println("enter the amount:");
      amount=sc.nextInt();
      switch(option)
        {
          case 1:   
             c=a-b;
            System.out.println("the addition value is"+c);
          break;
          /*case 2:
            ;
            System.out.println("the subtract value"+num3);
          break;
          case 3:
            num3=balance;
            System.out.println("the division value is"+balance);
            break;
          case 4:
            num3=num1*num2;
            System.out.println("the multiple value is"+num3);
          case 5:
            num3=num1%num2;
            System.out.println("the %division value is"+num3);
           break;*/
          default:
            System.out.println("the mission faild");
        }
    }
  }