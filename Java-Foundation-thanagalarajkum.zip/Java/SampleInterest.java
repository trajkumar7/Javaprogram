class SampleInterest{
  public static void main(String args[]){
    int p,t,r;
     p=1000;
     t=12;
     r=4;
    float simple=((p*t*r)/100);
    System.out.println("the simple interset is"+simple);
  }
}