class Sample1{
  public static void main(String args[]){
    int x=123,y=458;
   String str1="123",str2="458";
    System.out.println(x+y);
    System.out.println(str1+str2);
    
  }
}