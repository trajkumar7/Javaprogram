class AreaOfTriangle{
  public static void main(String args[]){
    int a=4,b=7;
     int A=((a*b)/2);
    System.out.println("AreaOfTriangle of square is"+A);
  }
}