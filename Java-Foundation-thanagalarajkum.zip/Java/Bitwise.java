class Bitwise{
  public static void main(String args[]){
    int a=154,b=400;
    System.out.println("the bitwise &"+ (a&b));
    System.out.println("the bitwise |"+(a|b));
    System.out.println("the bitwise ^" + (a^b));
    System.out.println("the shift <<"+(a<<2));
  }
}