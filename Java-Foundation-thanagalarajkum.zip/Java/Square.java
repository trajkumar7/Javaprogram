//Distance b/w two points
import java.util.*;
class Square{
  public static void main(String args[]){
    int x1,x2,y1,y2;
  	Scanner read = new Scanner(System.in); // Input stream is used
    System.out.println("enter x1 value");
    x1=read.nextInt();
    System.out.println("enter x2 value");
    x2=read.nextInt();
    System.out.println("enter y1 value");
    y1=read.nextInt();
    System.out.println("enter y2 value");
    y2=read.nextInt();
    //double X=((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    //double dist= Math.sqrt(X);
    double dis=Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    System.out.println("the distance b/w  two points "+dis);
    
    

     
  }
}