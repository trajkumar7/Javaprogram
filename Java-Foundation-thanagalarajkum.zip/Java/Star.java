//write SquarePattern program in loop
/*class Star
  {
    public static void main(String args[])
    {
      for(int i=1;i<=5;i++)
        {
          for(int j=1;j<=5;j++)
            {
              System.out.print("*"+" ");
            }
          System.out.println();
        }
    }
  }*/

/*// print the * ** *** **** rectangle
class Star{
  public static void main(String args[]){
    for(int i=1;i<=5;i++){
      for(int j=1;j<=i;j++){
        System.out.print("*"+" ");
      }
      System.out.println();
    }
  }
}  */

// inverted triangle  
/*class Star{
  public static void main(String args[]){
    for(int i=1;i<=5;i++){
      for(int j=i;j<=5;j++){
        System.out.print("*"+" ");
      }
      System.out.println();
    }
  }
}*/

// inverted triangle
/*class Star{
  public static void main(String args[]){
     for(int i=5;i>0;i--){
      for(int j=0;j<=i;j++){
        System.out.print("*"+" ");
      }
      System.out.println();
    }
  }
}*/

// left hand inverted triangle
//Left Angle Trinagle Pattern
import java.util.*;
class Star
  {
    public static void main(String args[]){
      Scanner sc=new Scanner(System.in);
      System.out.println("enter n value");
      int n=sc.nextInt();
      for(int i=1;i<=n;i++)
        {
          for(int j=i;j<=n;j++)
            {
              System.out.print(" ");
            }
          for(int v=1;v<=i;v++)
            {
              System.out.print("*");
            }
          System.out.println("");
        }
    }
  }

//right Angle Trinagle Pattern

/*class Star
  {
    public static void main(String args[]){
           
      for(int i=0;i<=5;i++)
        {
          for(int j=0;j<=i;j++)
            {
              System.out.print(" ");
            }
          for(int k=5;k>i;k--)
            {
              System.out.print("*");
            }
          System.out.println("");
        }
    }
  }*/


