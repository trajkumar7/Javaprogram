public class helloworld{
 public static void main(String[]args){
   System.out.println("welcome to java");
 }

  
}

  