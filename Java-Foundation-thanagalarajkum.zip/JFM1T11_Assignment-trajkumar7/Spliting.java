/* JFM1T11_Assignment6:

   Write a program to sort an array containing alphabets, special symbols and numbers.
   Prompt the user input from the terminal.
   
   Sample Input: bit01$$Lab02s03!@!!
   
   Expected Output: 
   Characters: bitLabs
   Numbers: 010203
   Special characters: $$!@!!

*/

import java.util.Scanner;

public class Spliting  { 

//main method

//take input from user

//call splitString method

//create splitString method in that initialize alpha, num and special to stringBuffer

//check if the entered string is digit,alpha and special using if condition

//printing seperatly characters in character, numbers in number and special characters in special character

}