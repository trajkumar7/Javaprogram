import simple.*;
class Example{
  public static void main(String args[]){
    MyClass my= new MyClass();
    my.display();
  }
}