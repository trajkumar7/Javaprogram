/*//Parameterized constructor
import java.util.*;
class Employ
  {
    String name;
    int rno;
    Employ(String sname,int rollno)
    {
      name=sname;
      rno=rollno;
    }
    public void display()
    {
      System.out.println("name="+name+" "+"rollno="+" "+rno);
    }
    public static void main(String args[])
    {
     
      Employ em=new Employ("anudeep",110);
      em.display();
    }
  }

/*class Constructor
  {
    Constructor(String empname,int id)
    {
      System.out.println("name="+empname+" "+"id="+id);
    }
    public static void main(String args[])
    {
      Constructor obj=new Constructor("anudeep",110);
    }
  }*/
//constructor
/*class Employ{
  Employ(){
    int rollno; String sname;
    System.out.println("name="+sname+" "+"rollno="+" "+rollno);
  }
  public static void main(String[]args){
    Employ em=new Employ("anudeep",110);
  }
}*/